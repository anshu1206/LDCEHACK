const BASE_URL = "http://127.0.0.1:5000";

// Navigation
function goTo(page) {
    window.location.href = page;
}

// Analyze
async function analyze() {
    const text = document.getElementById("complaint").value;

    const res = await fetch(`${BASE_URL}/analyze`, {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({ complaint: text })
    });

    const data = await res.json();

    document.getElementById("result").innerHTML = `
        <div class="card">
            <h3>Result</h3>
            Category: ${data.category}<br>
            Priority: <span class="${data.priority.toLowerCase()}">${data.priority}</span><br>
            SLA: ${data.sla}<br>
            Recommendation: ${data.recommendation}
        </div>
    `;
}

// Load complaints
async function loadComplaints() {
    const res = await fetch(`${BASE_URL}/complaints`);
    const data = await res.json();

    let html = "";

    data.forEach(c => {
        html += `
        <div class="card">
            <p>${c.text}</p>
            <p>Priority: <span class="${c.priority.toLowerCase()}">${c.priority}</span></p>
            <p>Status: <span class="status ${c.status === 'Resolved' ? 'resolved' : 'pending'}">${c.status}</span></p>

            <button class="primary" onclick="markResolved('${c.text}')">Mark Resolved</button>
        </div>
        `;
    });

    document.getElementById("list").innerHTML = html;
}

// Update status
async function markResolved(text) {
    await fetch(`${BASE_URL}/update-status`, {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({ text, status: "Resolved" })
    });

    loadComplaints();
}

// Stats
async function loadStats() {
    const res = await fetch(`${BASE_URL}/stats`);
    const data = await res.json();

    new Chart(document.getElementById("chart"), {
        type: "doughnut",
        data: {
            labels: ["High", "Medium", "Low"],
            datasets: [{
                data: [
                    data.priority.high,
                    data.priority.medium,
                    data.priority.low
                ],
                backgroundColor: ["#e74c3c", "#f39c12", "#2ecc71"]
            }]
        }
    });
}