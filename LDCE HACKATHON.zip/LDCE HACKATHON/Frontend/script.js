const BASE_URL = "http://127.0.0.1:5000";

// Navigation
function goTo(page) {
    window.location.href = page;
}
function downloadFile() {
    const type = document.getElementById("exportType").value;
    
    window.open(`${BASE_URL}/export/${type}`, "_blank");
}
// Analyze
async function analyze() {
    const text = document.getElementById("complaint").value;
    const city = document.getElementById("city")?.value;
    const area = document.getElementById("area")?.value;
    
    const res = await fetch(`${BASE_URL}/analyze`, {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({ complaint: text,city,area })
    });

    const data = await res.json();

    document.getElementById("result").innerHTML = `
        <div class="card">
            <h3>Result</h3>
            Category: ${data.category}<br>
            Priority: <span class="${data.priority.toLowerCase()}">${data.priority}</span><br>
            SLA: ${data.sla}<br>
            City: ${data.city || "-"}<br>
            Area: ${data.area || "-"}<br>
            Recommendation: ${data.recommendation}
        </div>
    `;
}

// Load complaints
async function loadComplaints() {
    const res = await fetch(`${BASE_URL}/complaints`);
    const data = await res.json();

    let html = "";

    data.forEach(c => {
        const isResolved = c.status === "Resolved";

       html += `
<div class="card">
    <p>${c.text}</p>

    <p>
        Priority: 
        <span class="${c.priority.toLowerCase()}">${c.priority}</span>
    </p>

    <p>
        Status: 
        <span class="status ${isResolved ? 'resolved' : 'pending'}">
            ${c.status}
        </span>
    </p>

    <button class="${isResolved ? 'secondary' : 'primary'}"
        onclick="toggleStatus('${c._id}', '${c.status}')">
        ${isResolved ? 'Reopen Complaint' : 'Mark Resolved'}
    </button>
</div>
`;
    });

    document.getElementById("list").innerHTML = html;
}

// Update status
async function markResolved(text) {
    await fetch(`${BASE_URL}/update-status`, {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({ text, status: "Resolved" })
    });

    loadComplaints();
}

// Stats
async function loadStats() {
    const res = await fetch(`${BASE_URL}/stats`);
    const data = await res.json();

    new Chart(document.getElementById("chart"), {
        type: "doughnut",
        data: {
            labels: ["High", "Medium", "Low"],
            datasets: [{
                data: [
                    data.priority.high,
                    data.priority.medium,
                    data.priority.low
                ],
                backgroundColor: ["#e74c3c", "#f39c12", "#2ecc71"]
            }]
        }
    });
}
async function toggleStatus(id, currentStatus) {
    const newStatus = currentStatus === "Resolved" ? "Pending" : "Resolved";

    await fetch(`${BASE_URL}/update-status`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            id: id,
            status: newStatus
        })
    });

    loadComplaints();
}
function exportAll() {
    window.open($`{BASE_URL}/export/csv`, "_blank");
    window.open($`{BASE_URL}/export/pdf`, "_blank");
}
function exportCSV() {
    window.location.href = $`{BASE_URL}/export/csv`;
}

// PDF
function exportPDF() {
    window.location.href = $`{BASE_URL}/export/pdf`;
}

// 🖨️ PRINT
function printPage() {
    window.print();
}


function startVoice() {
    // Check support
    if (!('webkitSpeechRecognition' in window)) {
        alert("Voice recognition not supported. Use Google Chrome.");
        return;
    }

    const recognition = new webkitSpeechRecognition();

    recognition.lang = "en-US";
    recognition.continuous = false;
    recognition.interimResults = true; // 👈 live typing

    recognition.onstart = () => {
        console.log("🎙️ Listening...");
    };

    recognition.onresult = (event) => {
        let transcript = "";

        for (let i = event.resultIndex; i < event.results.length; i++) {
            transcript += event.results[i][0].transcript;
        }

        // Live update text box
        document.getElementById("complaint").value = transcript;
    };

    recognition.onerror = (event) => {
        console.error("Voice error:", event.error);
        alert("Error: " + event.error);
    };

    recognition.onend = () => {
        console.log("🎤 Stopped listening");
    };

    recognition.start();
}